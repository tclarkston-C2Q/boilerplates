
# Healthcare Management Admin Dashboard (Elderly Patients)

React Native Web + Expo starter kit.

## Quick run

1. `cd elderly-care-admin`
2. `npm install`
3. `npx expo start --web`
