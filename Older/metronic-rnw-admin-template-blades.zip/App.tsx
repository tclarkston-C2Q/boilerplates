import "./global.css";
import React, { useState } from "react";
import { SafeAreaView, View } from "react-native";
import { GluestackUIProvider } from "@gluestack-ui/themed";
import { config } from "@gluestack-ui/config";
import { Sidebar, AppRoute } from "./src/components/Sidebar";
import { TopBar } from "./src/components/TopBar";
import { DashboardScreen } from "./src/screens/dashboard/DashboardScreen";
import { UsersScreen } from "./src/screens/users/UsersScreen";
import { SettingsScreen } from "./src/screens/settings/SettingsScreen";
import { LoginScreen } from "./src/screens/auth/LoginScreen";

export default function App() {
  const [activeRoute, setActiveRoute] = useState<AppRoute>("operations-dashboard");

  const renderContent = () => {
    if (activeRoute === "login") {
      return (
        <LoginScreen onLogin={() => setActiveRoute("operations-dashboard")} />
      );
    }

    if (activeRoute.startsWith("users-")) {
      return <UsersScreen />;
    }

    if (activeRoute.startsWith("settings-")) {
      return <SettingsScreen />;
    }

    if (activeRoute.startsWith("billing-")) {
      // Placeholder: reuse dashboard shell for billing views
      return <DashboardScreen />;
    }

    // operations-* and any other default
    return <DashboardScreen />;
  };

  const showChrome = activeRoute !== "login";

  return (
    <GluestackUIProvider config={config}>
      <SafeAreaView className="flex-1 bg-slate-950">
        <View className="flex-1 flex-row">
          {showChrome && (
            <Sidebar activeRoute={activeRoute} onRouteChange={setActiveRoute} />
          )}

          <View className="flex-1">
            {showChrome && <TopBar onRouteChange={setActiveRoute} />}
            <View className="flex-1">{renderContent()}</View>
          </View>
        </View>
      </SafeAreaView>
    </GluestackUIProvider>
  );
}
