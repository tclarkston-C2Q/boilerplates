import React from "react";
import { View, Text, TextInput } from "react-native";
import {
  Avatar,
  AvatarFallbackText,
  Button,
  ButtonText,
} from "@gluestack-ui/themed";
import type { AppRoute } from "./Sidebar";

type TopBarProps = {
  onRouteChange: (route: AppRoute) => void;
};

export const TopBar: React.FC<TopBarProps> = ({ onRouteChange }) => {
  return (
    <View className="h-16 flex-row items-center justify-between px-6 border-b border-slate-800 bg-slate-950/80">
      <View className="flex-row items-center gap-4">
        <Text className="text-lg font-semibold text-slate-100">
          Metronic-style Admin
        </Text>
        <Text className="text-xs text-slate-500">
          React Native Web • NativeWind • Gluestack
        </Text>
      </View>

      <View className="flex-row items-center gap-4">
        <View className="hidden md:flex flex-row items-center rounded-lg bg-slate-900 border border-slate-700 px-3 py-1.5 w-64">
          <TextInput
            placeholder="Search..."
            placeholderTextColor="#64748b"
            style={{
              flex: 1,
              color: "#e2e8f0",
              fontSize: 13,
            }}
          />
        </View>

        <Button
          size="sm"
          variant="outline"
          action="primary"
          onPress={() => onRouteChange("operations-dashboard")}
        >
          <ButtonText>Go to Dashboard</ButtonText>
        </Button>

        <Button
          size="sm"
          variant="outline"
          action="secondary"
          onPress={() => onRouteChange("login")}
        >
          <ButtonText>Sign Out</ButtonText>
        </Button>

        <Avatar size="md" className="ml-2">
          <AvatarFallbackText>AD</AvatarFallbackText>
        </Avatar>
      </View>
    </View>
  );
};
