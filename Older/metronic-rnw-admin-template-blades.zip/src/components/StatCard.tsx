import React from "react";
import { View, Text } from "react-native";

type StatCardProps = {
  label: string;
  value: string;
  change?: string;
};

export const StatCard: React.FC<StatCardProps> = ({ label, value, change }) => {
  return (
    <View className="flex-1 rounded-xl bg-slate-900 border border-slate-800 px-4 py-3 mr-3 mb-3">
      <Text className="text-xs text-slate-400 mb-1">{label}</Text>
      <Text className="text-2xl font-semibold text-slate-50">{value}</Text>
      {change ? (
        <Text
          className={`mt-1 text-xs ${
            change.startsWith("+") ? "text-emerald-400" : "text-rose-400"
          }`}
        >
          {change} vs last period
        </Text>
      ) : null}
    </View>
  );
};
