import React from "react";
import { Pressable, Text, View } from "react-native";

export type AppRoute =
  | "operations-dashboard"
  | "operations-health"
  | "users-list"
  | "users-roles"
  | "settings-general"
  | "settings-security"
  | "billing-overview"
  | "billing-invoices"
  | "login";

type AppArea = "operations" | "users" | "settings" | "billing";

type PrimaryItem = {
  id: AppArea;
  label: string;
  short: string;
};

type SecondaryItem = {
  id: AppRoute;
  area: AppArea;
  label: string;
  description?: string;
};

const PRIMARY_ITEMS: PrimaryItem[] = [
  { id: "operations", label: "Operations", short: "Ops" },
  { id: "users", label: "Users", short: "Usr" },
  { id: "settings", label: "Settings", short: "Cfg" },
  { id: "billing", label: "Billing", short: "Bil" },
];

const SECONDARY_ITEMS: SecondaryItem[] = [
  {
    id: "operations-dashboard",
    area: "operations",
    label: "Executive dashboard",
    description: "KPIs & trends",
  },
  {
    id: "operations-health",
    area: "operations",
    label: "System health",
    description: "Uptime & errors",
  },
  {
    id: "users-list",
    area: "users",
    label: "Directory",
    description: "All members",
  },
  {
    id: "users-roles",
    area: "users",
    label: "Roles & access",
    description: "Permissions model",
  },
  {
    id: "settings-general",
    area: "settings",
    label: "General",
    description: "Workspace defaults",
  },
  {
    id: "settings-security",
    area: "settings",
    label: "Security",
    description: "Policies & controls",
  },
  {
    id: "billing-overview",
    area: "billing",
    label: "Revenue overview",
    description: "MRR & ARPU",
  },
  {
    id: "billing-invoices",
    area: "billing",
    label: "Invoices",
    description: "Billing history",
  },
];

type SidebarProps = {
  activeRoute: AppRoute;
  onRouteChange: (route: AppRoute) => void;
};

export const Sidebar: React.FC<SidebarProps> = ({
  activeRoute,
  onRouteChange,
}) => {
  const activeArea =
    SECONDARY_ITEMS.find((item) => item.id === activeRoute)?.area ??
    "operations";

  return (
    <View className="flex-row h-full bg-slate-950 border-r border-slate-800">
      {/* Primary blade (apps) */}
      <View className="w-16 bg-slate-950 border-r border-slate-800 pt-4 items-center">
        <View className="mb-6 px-2">
          <Text className="text-[10px] font-semibold text-primary-500 text-center">
            RNW
          </Text>
          <Text className="text-[9px] text-slate-500 text-center">
            Admin
          </Text>
        </View>
        {PRIMARY_ITEMS.map((item) => {
          const isActive = item.id === activeArea;
          return (
            <Pressable
              key={item.id}
              onPress={() => {
                const firstRoute = SECONDARY_ITEMS.find(
                  (x) => x.area === item.id
                );
                if (firstRoute) {
                  onRouteChange(firstRoute.id);
                }
              }}
              className={`w-10 h-10 mb-3 rounded-xl items-center justify-center ${
                isActive
                  ? "bg-primary-600 shadow-sm"
                  : "bg-slate-900 border border-slate-800"
              }`}
            >
              <Text
                className={`text-[10px] font-semibold ${
                  isActive ? "text-white" : "text-slate-300"
                }`}
              >
                {item.short}
              </Text>
            </Pressable>
          );
        })}
      </View>

      {/* Secondary blade (sections within app) */}
      <View className="w-56 bg-slate-950">
        <View className="px-4 pt-4 pb-3 border-b border-slate-800">
          <Text className="text-xs text-slate-500 mb-0.5">Workspace</Text>
          <Text className="text-sm font-semibold text-slate-100">
            {PRIMARY_ITEMS.find((x) => x.id === activeArea)?.label ??
              "Operations"}
          </Text>
        </View>

        <View className="flex-1 py-3">
          {SECONDARY_ITEMS.filter((x) => x.area === activeArea).map(
            (item) => {
              const isActive = item.id === activeRoute;
              return (
                <Pressable
                  key={item.id}
                  onPress={() => onRouteChange(item.id)}
                  className={`mx-2 mb-1 rounded-lg px-3 py-2 ${
                    isActive
                      ? "bg-primary-600/90"
                      : "bg-transparent hover:bg-slate-900"
                  }`}
                >
                  <Text
                    className={`text-[13px] ${
                      isActive
                        ? "text-white font-semibold"
                        : "text-slate-200"
                    }`}
                  >
                    {item.label}
                  </Text>
                  {item.description ? (
                    <Text className="text-[11px] text-slate-400 mt-0.5">
                      {item.description}
                    </Text>
                  ) : null}
                </Pressable>
              );
            }
          )}
        </View>

        <View className="px-4 py-3 border-t border-slate-800">
          <Pressable
            onPress={() => onRouteChange("login")}
            className="rounded-lg px-3 py-2 bg-slate-900 border border-slate-800"
          >
            <Text className="text-[12px] text-slate-200 font-medium">
              Sign out
            </Text>
            <Text className="text-[10px] text-slate-500 mt-0.5">
              Return to login shell
            </Text>
          </Pressable>

          <View className="mt-4">
            <Text className="text-[10px] text-slate-500">
              © {new Date().getFullYear()} Your Company
            </Text>
            <Text className="text-[10px] text-slate-500">
              RNW Admin • Blade layout
            </Text>
          </View>
        </View>
      </View>
    </View>
  );
};
