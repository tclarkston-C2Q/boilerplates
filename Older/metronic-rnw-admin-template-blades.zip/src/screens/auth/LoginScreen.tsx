import React from "react";
import { View, Text, KeyboardAvoidingView, Platform } from "react-native";
import {
  Button,
  ButtonText,
  FormControl,
  FormControlLabel,
  FormControlLabelText,
  Input,
  InputField,
  Checkbox,
  CheckboxIndicator,
  CheckboxIcon,
  CheckboxLabel,
  CheckboxGroup,
} from "@gluestack-ui/themed";

type LoginScreenProps = {
  onLogin?: () => void;
};

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  return (
    <KeyboardAvoidingView
      className="flex-1 bg-slate-950 items-center justify-center px-4"
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <View className="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 px-6 py-8">
        <Text className="text-sm font-semibold text-primary-400 mb-2">
          Welcome back
        </Text>
        <Text className="text-2xl font-semibold text-slate-50 mb-1">
          Sign in to your admin
        </Text>
        <Text className="text-xs text-slate-400 mb-6">
          Use a test email/password — this is only a UI template.
        </Text>

        <FormControl className="mb-4">
          <FormControlLabel>
            <FormControlLabelText className="text-xs text-slate-300">
              Email
            </FormControlLabelText>
          </FormControlLabel>
          <Input>
            <InputField
              placeholder="you@company.com"
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </Input>
        </FormControl>

        <FormControl className="mb-2">
          <FormControlLabel>
            <FormControlLabelText className="text-xs text-slate-300">
              Password
            </FormControlLabelText>
          </FormControlLabel>
          <Input>
            <InputField
              placeholder="••••••••"
              secureTextEntry
              autoCapitalize="none"
            />
          </Input>
        </FormControl>

        <View className="flex-row items-center justify-between mb-4 mt-2">
          <CheckboxGroup>
            <Checkbox value="remember">
              <CheckboxIndicator>
                <CheckboxIcon />
              </CheckboxIndicator>
              <CheckboxLabel className="text-xs text-slate-300 ml-2">
                Remember me
              </CheckboxLabel>
            </Checkbox>
          </CheckboxGroup>

          <Text className="text-xs text-primary-400">Forgot password?</Text>
        </View>

        <Button
          size="md"
          action="primary"
          className="mt-2"
          onPress={onLogin}
        >
          <ButtonText>Sign in</ButtonText>
        </Button>

        <View className="mt-6 border-t border-slate-800 pt-4">
          <Text className="text-[11px] text-slate-500 text-center">
            Need a full auth flow? Hook this screen into your identity
            provider or backend service.
          </Text>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
};
