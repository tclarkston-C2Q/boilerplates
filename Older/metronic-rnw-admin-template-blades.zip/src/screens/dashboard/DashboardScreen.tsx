import React from "react";
import { Dimensions, ScrollView, View, Text } from "react-native";
import { StatCard } from "../../components/StatCard";
import { LineChart, BarChart } from "react-native-chart-kit";

const screenWidth = Dimensions.get("window").width;

export const DashboardScreen: React.FC = () => {
  const contentWidth = Math.min(screenWidth - 320, 1024);

  return (
    <ScrollView className="flex-1 bg-slate-950">
      <View className="px-6 pt-6 pb-10">
        <Text className="text-xl font-semibold text-slate-100 mb-1">
          Executive dashboard
        </Text>
        <Text className="text-sm text-slate-400 mb-6">
          High-level KPIs and trends across your applications.
        </Text>

        <View className="flex-row flex-wrap -mr-3">
          <StatCard label="Active Users" value="18,420" change="+4.2%" />
          <StatCard label="Subscriptions" value="1,284" change="+1.3%" />
          <StatCard label="Churn" value="3.4%" change="-0.6%" />
          <StatCard label="Error Rate" value="0.23%" change="+0.02%" />
        </View>

        <View className="mt-6 flex-row flex-wrap gap-6">
          <View className="rounded-xl bg-slate-900 border border-slate-800 p-4 flex-1 min-w-[320px]">
            <Text className="text-sm font-medium text-slate-100 mb-2">
              Revenue (last 12 months)
            </Text>
            <LineChart
              data={{
                labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
                datasets: [
                  {
                    data: [42, 45, 47, 52, 58, 63],
                  },
                ],
              }}
              width={contentWidth}
              height={220}
              chartConfig={{
                backgroundGradientFrom: "#020617",
                backgroundGradientTo: "#020617",
                color: (opacity = 1) => `rgba(56, 189, 248, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(148, 163, 184, ${opacity})`,
                propsForDots: {
                  r: "3",
                },
              }}
              bezier
              style={{
                marginTop: 8,
                borderRadius: 12,
              }}
            />
          </View>

          <View className="rounded-xl bg-slate-900 border border-slate-800 p-4 flex-1 min-w-[320px]">
            <Text className="text-sm font-medium text-slate-100 mb-2">
              New signups per plan
            </Text>
            <BarChart
              data={{
                labels: ["Free", "Pro", "Business"],
                datasets: [
                  {
                    data: [420, 280, 96],
                  },
                ],
              }}
              width={contentWidth < 720 ? contentWidth : contentWidth / 2}
              height={220}
              chartConfig={{
                backgroundGradientFrom: "#020617",
                backgroundGradientTo: "#020617",
                color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`,
                labelColor: (opacity = 1) => `rgba(148, 163, 184, ${opacity})`,
              }}
              style={{
                marginTop: 8,
                borderRadius: 12,
              }}
            />
          </View>
        </View>
      </View>
    </ScrollView>
  );
};
