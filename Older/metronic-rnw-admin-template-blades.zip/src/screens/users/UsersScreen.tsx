import React from "react";
import { ScrollView, View, Text } from "react-native";
import {
  Button,
  ButtonText,
  Input,
  InputField,
  FormControl,
  FormControlLabel,
  FormControlLabelText,
} from "@gluestack-ui/themed";

const MOCK_USERS = [
  { id: "1", name: "Jane Doe", role: "Admin", status: "Active" },
  { id: "2", name: "John Smith", role: "Manager", status: "Active" },
  { id: "3", name: "Alex Johnson", role: "Viewer", status: "Invited" },
  { id: "4", name: "Sam Brown", role: "Support", status: "Disabled" },
];

export const UsersScreen: React.FC = () => {
  return (
    <ScrollView className="flex-1 bg-slate-950">
      <View className="px-6 pt-6 pb-10">
        <Text className="text-xl font-semibold text-slate-100 mb-1">
          Directory
        </Text>
        <Text className="text-sm text-slate-400 mb-6">
          Manage workspace members and access levels.
        </Text>

        <View className="rounded-xl bg-slate-900 border border-slate-800 p-4 mb-6">
          <Text className="text-sm font-medium text-slate-100 mb-4">
            Quick add user
          </Text>
          <View className="flex-row flex-wrap items-end gap-4">
            <FormControl className="flex-1 min-w-[200px]">
              <FormControlLabel>
                <FormControlLabelText className="text-xs text-slate-300">
                  Full name
                </FormControlLabelText>
              </FormControlLabel>
              <Input>
                <InputField placeholder="e.g. Jane Doe" />
              </Input>
            </FormControl>

            <FormControl className="flex-1 min-w-[200px]">
              <FormControlLabel>
                <FormControlLabelText className="text-xs text-slate-300">
                  Email
                </FormControlLabelText>
              </FormControlLabel>
              <Input>
                <InputField
                  placeholder="e.g. jane@company.com"
                  keyboardType="email-address"
                />
              </Input>
            </FormControl>

            <Button size="md" action="primary" className="mt-2">
              <ButtonText>Invite</ButtonText>
            </Button>
          </View>
        </View>

        <View className="rounded-xl bg-slate-900 border border-slate-800">
          <View className="flex-row px-4 py-3 border-b border-slate-800">
            <Text className="flex-[2] text-xs font-semibold text-slate-400">
              Name
            </Text>
            <Text className="flex-[1] text-xs font-semibold text-slate-400">
              Role
            </Text>
            <Text className="flex-[1] text-xs font-semibold text-slate-400">
              Status
            </Text>
            <Text className="w-24 text-xs font-semibold text-slate-400 text-right">
              Actions
            </Text>
          </View>

          {MOCK_USERS.map((user, index) => (
            <View
              key={user.id}
              className={`flex-row items-center px-4 py-3 ${
                index !== MOCK_USERS.length - 1
                  ? "border-b border-slate-800"
                  : ""
              }`}
            >
              <Text className="flex-[2] text-sm text-slate-100">
                {user.name}
              </Text>
              <Text className="flex-[1] text-sm text-slate-300">
                {user.role}
              </Text>
              <Text
                className={`flex-[1] text-xs font-medium ${
                  user.status === "Active"
                    ? "text-emerald-400"
                    : user.status === "Disabled"
                    ? "text-rose-400"
                    : "text-amber-300"
                }`}
              >
                {user.status}
              </Text>
              <View className="w-24 flex-row justify-end gap-2">
                <Button size="xs" variant="outline" action="primary">
                  <ButtonText>Edit</ButtonText>
                </Button>
                <Button size="xs" variant="outline" action="secondary">
                  <ButtonText>More</ButtonText>
                </Button>
              </View>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};
