import React from "react";
import { ScrollView, View, Text } from "react-native";
import {
  Button,
  ButtonText,
  FormControl,
  FormControlLabel,
  FormControlLabelText,
  Input,
  InputField,
  Switch,
  SwitchTrack,
  SwitchThumb,
} from "@gluestack-ui/themed";

export const SettingsScreen: React.FC = () => {
  return (
    <ScrollView className="flex-1 bg-slate-950">
      <View className="px-6 pt-6 pb-10">
        <Text className="text-xl font-semibold text-slate-100 mb-1">
          Settings
        </Text>
        <Text className="text-sm text-slate-400 mb-6">
          Control global application settings and defaults.
        </Text>

        <View className="rounded-xl bg-slate-900 border border-slate-800 p-4 mb-6">
          <Text className="text-sm font-medium text-slate-100 mb-4">
            General
          </Text>

          <FormControl className="mb-4">
            <FormControlLabel>
              <FormControlLabelText className="text-xs text-slate-300">
                Workspace name
              </FormControlLabelText>
            </FormControlLabel>
            <Input>
              <InputField placeholder="e.g. WireServers Prod" />
            </Input>
          </FormControl>

          <FormControl className="mb-4">
            <FormControlLabel>
              <FormControlLabelText className="text-xs text-slate-300">
                Support email
              </FormControlLabelText>
            </FormControlLabel>
            <Input>
              <InputField
                placeholder="support@yourcompany.com"
                keyboardType="email-address"
              />
            </Input>
          </FormControl>

          <View className="flex-row items-center justify-between mt-2">
            <View>
              <Text className="text-sm text-slate-100">
                Maintenance mode
              </Text>
              <Text className="text-xs text-slate-400 mt-1 w-64">
                Temporarily show a maintenance banner to all users.
              </Text>
            </View>
            <Switch>
              <SwitchTrack>
                <SwitchThumb />
              </SwitchTrack>
            </Switch>
          </View>

          <Button size="md" action="primary" className="mt-6 self-start">
            <ButtonText>Save changes</ButtonText>
          </Button>
        </View>

        <View className="rounded-xl bg-slate-900 border border-slate-800 p-4">
          <Text className="text-sm font-medium text-slate-100 mb-4">
            Security
          </Text>

          <View className="flex-row items-center justify-between mb-4">
            <View className="w-3/4">
              <Text className="text-sm text-slate-100">
                Enforce 2FA for admins
              </Text>
              <Text className="text-xs text-slate-400 mt-1">
                Require multi-factor authentication for all admin accounts.
              </Text>
            </View>
            <Switch>
              <SwitchTrack>
                <SwitchThumb />
              </SwitchTrack>
            </Switch>
          </View>

          <View className="flex-row items-center justify-between mb-4">
            <View className="w-3/4">
              <Text className="text-sm text-slate-100">
                Session timeout
              </Text>
              <Text className="text-xs text-slate-400 mt-1">
                Auto sign-out users after inactivity.
              </Text>
            </View>
            <Text className="text-xs text-slate-300">30 minutes</Text>
          </View>

          <Button
            size="md"
            variant="outline"
            action="secondary"
            className="mt-2 self-start"
          >
            <ButtonText>View audit logs</ButtonText>
          </Button>
        </View>
      </View>
    </ScrollView>
  );
};
