# Metronic-style React Native Web Admin Template (Blade Layout)

This template gives you a **Metronic-inspired, blade-style admin layout** built with:

- React Native (via Expo) + React Native Web
- NativeWind (Tailwind-style classes for React Native)
- Gluestack UI (component library)
- react-native-chart-kit (charts)

It is **not** a clone of Metronic and does not include any Metronic code or assets. It provides a similar, modern admin shell with:

- Two-level **left “blade” navigation** (primary app rail + secondary app menu)
- Top header bar (search, CTAs, avatar)
- Dashboard with KPI cards and charts
- Users and Settings sections
- Login screen (UI only)

---

## 1. Prerequisites

- Node.js 18+
- `npm` or `yarn`
- Expo tooling (via `npx create-expo-app`)

---

## 2. Create the Expo project

```bash
npx create-expo-app metronic-rnw-admin --template
cd metronic-rnw-admin
```

Use the default template (TypeScript recommended but JavaScript is fine).

---

## 3. Install dependencies

### Core + styling

```bash
npx expo install nativewind react-native-reanimated react-native-safe-area-context
```

### Gluestack UI

```bash
npm install @gluestack-ui/themed @gluestack-ui/config @gluestack-ui/react-native
```

### Charts

```bash
npx expo install react-native-chart-kit react-native-svg
```

### Tailwind / NativeWind tooling

```bash
npm install -D tailwindcss prettier-plugin-tailwindcss
npx tailwindcss init
```

---

## 4. Copy the template files

From this zip, copy the following into your Expo project root, **overwriting** existing files:

- `App.tsx`
- `babel.config.js`
- `metro.config.js`
- `tailwind.config.js`
- `global.css`
- `src/**` (entire folder)

Folder structure should look like:

```text
metronic-rnw-admin/
  App.tsx
  babel.config.js
  metro.config.js
  tailwind.config.js
  global.css
  src/
    components/
      Sidebar.tsx
      TopBar.tsx
      StatCard.tsx
    screens/
      dashboard/DashboardScreen.tsx
      users/UsersScreen.tsx
      settings/SettingsScreen.tsx
      auth/LoginScreen.tsx
```

---

## 5. Configure Tailwind / NativeWind

`tailwind.config.js` is already wired for NativeWind and extends a blue/green palette. `global.css` contains the Tailwind directives.

**tailwind.config.js**

- Scans `App.tsx` and `src/**/*.{js,jsx,ts,tsx}`
- Uses `nativewind/preset`
- Adds `primary` and `accent` color scales

**global.css**

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

---

## 6. Metro & Babel config

- `babel.config.js` enables `nativewind/babel` and `jsxImportSource: "nativewind"`
- `metro.config.js` hooks NativeWind into Expo Metro via `withNativeWind`

You typically won’t need to modify these unless you heavily customize your bundler setup.

---

## 7. app.json (Web bundler)

In `app.json`, make sure the web config uses Metro:

```jsonc
{
  "expo": {
    // ... other settings ...
    "web": {
      "bundler": "metro"
    }
  }
}
```

---

## 8. Run the project

```bash
npm run start
```

When the Expo dev tools open, choose **Web** (or press `w` in the terminal).

You should see:

- A **two-column left blade navigation**:
  - Narrow primary rail (apps)
  - Wider secondary blade (sections for the selected app)
- A **top header** with title, search, buttons, and avatar
- A **Dashboard** with cards and charts
- **Users** and **Settings** sections
- A **Login** screen (when you sign out)

---

## 9. Navigation model

The template uses a simple, type-safe navigation model:

- **Primary apps (blades)**:
  - Operations
  - Users
  - Settings
  - Billing
- **Routes (sub-pages)**:
  - `operations-dashboard`
  - `operations-health`
  - `users-list`
  - `users-roles`
  - `settings-general`
  - `settings-security`
  - `billing-overview`
  - `billing-invoices`
  - `login` (special case, hides chrome)

`Sidebar.tsx` renders both the primary rail and the secondary blade. `App.tsx` decides which screen to display based on the active route.

---

## 10. Screen mapping

Today, the mapping is intentionally lean and easy to extend:

- Any `operations-*` route → `DashboardScreen`
- Any `users-*` route → `UsersScreen`
- Any `settings-*` route → `SettingsScreen`
- Any `billing-*` route → `DashboardScreen` (placeholder)
- `login` → `LoginScreen`

You can later split or add more granular screens (e.g., dedicated `HealthScreen`, `BillingScreen`, etc.).

---

## 11. Where to extend

- **Add more sub-pages / blades**: edit `SECONDARY_ITEMS` in `Sidebar.tsx` and expand the route mapping in `App.tsx`.
- **Add real auth**: replace the `LoginScreen` callback with your auth provider / API.
- **Wire APIs**: connect `DashboardScreen`, `UsersScreen`, and `SettingsScreen` to your backend or microservices.
- **Routing library**: if you want URL-based routing, wire these routes into Expo Router or React Navigation for web.

This gives you a production-grade starting point for a Metronic-style admin shell on React Native Web, without pulling in any proprietary Metronic assets.
