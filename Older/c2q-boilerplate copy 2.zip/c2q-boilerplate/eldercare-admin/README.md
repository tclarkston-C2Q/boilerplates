
# Eldercare Admin Starter (Expo + Expo Router + NativeWind + Gluestack)

This is a minimal working skeleton. Expand by dropping the full code from prior message into pages/components.
