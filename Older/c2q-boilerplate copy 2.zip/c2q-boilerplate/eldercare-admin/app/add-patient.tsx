
import { View, Text } from 'react-native';
export default function AddPatient() {
  return (
    <View style={{flex:1,justifyContent:'center',alignItems:'center',backgroundColor:'#0f172a'}}>
      <Text style={{color:'white'}}>Add Patient Wizard Placeholder</Text>
    </View>
  );
}
