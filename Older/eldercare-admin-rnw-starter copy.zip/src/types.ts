import type { ViewId } from "./navigation";

export type View = ViewId;

export type PatientId = string | null;
