import React from "react";
import {Reports} from "../../src/components/Reports";
export default function ReportsScreen() {
  return <Reports />;
}
