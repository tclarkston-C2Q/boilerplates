import React from "react";
import {Vitals} from "../../src/components/Vitals";
export default function VitalsScreen() {
  return <Vitals />;
}
