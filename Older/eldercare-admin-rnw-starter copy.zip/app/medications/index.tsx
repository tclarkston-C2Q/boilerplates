import React from "react";
import {Medications} from "../../src/components/Medications";
export default function MedicationsScreen() {
  return <Medications />;
}
