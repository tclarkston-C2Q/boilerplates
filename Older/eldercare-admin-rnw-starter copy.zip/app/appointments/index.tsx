import React from "react";
import { AppointmentCalendarNative } from "../../src/components/AppointmentCalendarNative";

export default function AppointmentsScreen() {
  return <AppointmentCalendarNative />;
}
