import React from "react";
import {Team} from "../../src/components/Team";
export default function TeamScreen() {
  return <Team />;
}
