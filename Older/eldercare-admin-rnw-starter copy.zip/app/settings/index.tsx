import React from "react";
import {Settings} from "../../src/components/Settings";
export default function SettingsScreen() {
  return <Settings />;
}
