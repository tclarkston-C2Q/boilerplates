# Admin Blade Starter (Expo + Expo Router + NativeWind + Gluestack UI + Chart Kit)

Production-grade React Native UI scaffolding (no auth wiring). It includes: primary **left navigation**, per-app **left blades**, **Dashboard** (cards + charts), **Users** admin (CRUD UI), and **Admin** (login/logout/reset/change password/profile).

## Step-by-step setup

1. **Install Node.js** 18+ (recommend Node 20).
2. **Install dependencies**
   ```bash
   npm install
   ```
3. **Start the project**
   ```bash
   npm run start
   # press i for iOS, a for Android
   # or run:
   npm run web
   ```
4. **Folder map**
   - `app/_layout.tsx` — App shell (sidebar + topbar avatar menu)
   - `app/(dashboard)` — Overview, Reports, KPIs
   - `app/(users)` — List, Create, Edit, Roles
   - `app/(admin)` — Login, Reset/Change Password, Profile, Logout
   - `components/` — Shell, Blades, Forms, Charts
5. **Styling**
   - Tailwind (via NativeWind) with blue/green palette (`brand`/`accent`).
   - Gluestack UI primitives for inputs, buttons, menu, etc.
6. **Charts**
   - `react-native-chart-kit` examples in `components/ChartCard.tsx`.
7. **Next steps**
   - Plug in auth, add API calls, guard routes with Expo Router.

## Commands
```bash
npm run start
npm run ios
npm run android
npm run web
npm run typecheck
npm run lint
```
