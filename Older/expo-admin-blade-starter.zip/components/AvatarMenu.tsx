import React, { useState } from "react";
import { Pressable, Image } from "react-native";
import { Menu, MenuItem, MenuItemLabel } from "@gluestack-ui/themed";
import { router } from "expo-router";

export const AvatarMenu = () => {
  const [open, setOpen] = useState(false);
  return (
    <Menu isOpen={open} onClose={() => setOpen(false)} placement="bottom right" trigger={triggerProps => {
      return (
        <Pressable {...triggerProps} onPress={() => setOpen(!open)}>
          <Image source={{ uri: "https://i.pravatar.cc/80" }} style={{ width: 36, height: 36, borderRadius: 999 }} />
        </Pressable>
      );
    }}>
      <MenuItem onPress={() => { setOpen(false); router.push("/(admin)/profile"); }}>
        <MenuItemLabel>Profile</MenuItemLabel>
      </MenuItem>
      <MenuItem onPress={() => { setOpen(false); router.push("/(settings)"); }}>
        <MenuItemLabel>Settings</MenuItemLabel>
      </MenuItem>
      <MenuItem onPress={() => { setOpen(false); router.push("/(admin)/logout"); }}>
        <MenuItemLabel>Logout</MenuItemLabel>
      </MenuItem>
    </Menu>
  );
};
