import React from "react";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, VStack, HStack, Input, InputField, Select, SelectTrigger, SelectInput, SelectPortal, SelectBackdrop, SelectContent, SelectItem, SelectIcon, Text, Button, ButtonText } from "@gluestack-ui/themed";
import { ChevronDown } from "lucide-react-native";

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  role: z.enum(["Owner", "Admin", "Member"]),
  status: z.enum(["Active", "Suspended"])
});

export default function UserForm({ mode = "create" as "create" | "edit" }) {
  const { control, handleSubmit } = useForm({ resolver: zodResolver(schema), defaultValues: { role: "Member", status: "Active" } });
  const onSubmit = (data: any) => alert(`${mode === "create" ? "Created" : "Updated"} user: ${JSON.stringify(data, null, 2)}`);

  return (
    <Box className="bg-white rounded-3xl p-4 shadow-card">
      <VStack className="gap-4">
        <Controller control={control} name="name" render={({ field: { onChange, value } }) => (
          <Input className="rounded-2xl"><InputField placeholder="Full name" value={value} onChangeText={onChange} /></Input>
        )} />
        <Controller control={control} name="email" render={({ field: { onChange, value } }) => (
          <Input className="rounded-2xl"><InputField placeholder="Email" value={value} onChangeText={onChange} keyboardType="email-address" /></Input>
        )} />
        <HStack className="gap-3">
          <Controller control={control} name="role" render={({ field: { onChange, value } }) => (
            <Select selectedValue={value} onValueChange={onChange}>
              <SelectTrigger className="rounded-2xl">
                <SelectInput placeholder="Role" />
                <SelectIcon as={ChevronDown} />
              </SelectTrigger>
              <SelectPortal>
                <SelectBackdrop />
                <SelectContent>
                  <SelectItem label="Owner" value="Owner" />
                  <SelectItem label="Admin" value="Admin" />
                  <SelectItem label="Member" value="Member" />
                </SelectContent>
              </SelectPortal>
            </Select>
          )} />
          <Controller control={control} name="status" render={({ field: { onChange, value } }) => (
            <Select selectedValue={value} onValueChange={onChange}>
              <SelectTrigger className="rounded-2xl">
                <SelectInput placeholder="Status" />
                <SelectIcon as={ChevronDown} />
              </SelectTrigger>
              <SelectPortal>
                <SelectBackdrop />
                <SelectContent>
                  <SelectItem label="Active" value="Active" />
                  <SelectItem label="Suspended" value="Suspended" />
                </SelectContent>
              </SelectPortal>
            </Select>
          )} />
        </HStack>
        <HStack className="justify-end gap-2">
          <Button variant="outline" className="rounded-2xl border-slate-200"><ButtonText>Cancel</ButtonText></Button>
          <Button className="rounded-2xl bg-accent-600" onPress={handleSubmit(onSubmit)}>
            <ButtonText>{mode === "create" ? "Create user" : "Save changes"}</ButtonText>
          </Button>
        </HStack>
      </VStack>
    </Box>
  );
}
