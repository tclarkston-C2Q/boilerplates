import React from "react";
import { View, Pressable } from "react-native";
import { Link, usePathname } from "expo-router";
import { Text } from "@gluestack-ui/themed";
import { Home, Users, Settings, Shield } from "lucide-react-native";

const Item = ({ href, icon: Icon, label }: any) => {
  const pathname = usePathname();
  const active = pathname.startsWith(href);
  return (
    <Link href={href} asChild>
      <Pressable className={`px-3 py-3 rounded-2xl flex-row items-center gap-3 ${active ? "bg-slate-200" : "bg-transparent"}`}>
        <Icon size={18} />
        <Text className="font-medium">{label}</Text>
      </Pressable>
    </Link>
  );
};

export default function Sidebar() {
  return (
    <View className="w-60 bg-white border-r border-slate-100 p-3 gap-2">
      <Text className="text-slate-900 text-lg font-bold mb-2">Admin Kit</Text>
      <Item href="/(dashboard)" icon={Home} label="Dashboard" />
      <Item href="/(users)" icon={Users} label="Users" />
      <Item href="/(settings)" icon={Settings} label="Settings" />
      <Item href="/(admin)/login" icon={Shield} label="Admin" />
    </View>
  );
}
