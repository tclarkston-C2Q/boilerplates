import React from "react";
import { View, Pressable } from "react-native";
import { Link, usePathname } from "expo-router";
import { Text } from "@gluestack-ui/themed";
import * as Icons from "lucide-react-native";

type Item = { label: string; href: string; icon?: keyof typeof Icons };

export default function BladeNav({ title, items, children }: { title: string; items: Item[]; children: React.ReactNode }) {
  const pathname = usePathname();
  return (
    <View className="flex-1 flex-row">
      <View className="w-56 bg-white border-r border-slate-100 p-3">
        <Text className="text-slate-900 text-lg font-semibold mb-2">{title}</Text>
        {items.map((item) => {
          const Icon = item.icon ? (Icons as any)[item.icon] : null;
          const active = pathname === item.href;
          return (
            <Link key={item.href} href={item.href} asChild>
              <Pressable className={`px-3 py-2 rounded-2xl flex-row items-center gap-2 ${active ? "bg-brand-50" : ""}`}>
                {Icon ? <Icon size={18} color={active ? "#2563eb" : "#0f172a"} /> : null}
                <Text className={`${active ? "text-brand-700 font-semibold" : "text-slate-700"}`}>{item.label}</Text>
              </Pressable>
            </Link>
          );
        })}
      </View>
      <View className="flex-1">{children}</View>
    </View>
  );
}
