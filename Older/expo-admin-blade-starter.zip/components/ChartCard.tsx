import React from "react";
import { View } from "react-native";
import { Text } from "@gluestack-ui/themed";
import {
  LineChart,
  BarChart,
  PieChart,
  StackedBarChart,
  ProgressChart
} from "react-native-chart-kit";

type Props = {
  title: string;
  type: "line" | "bar" | "pie" | "stackedBar" | "progress";
  width: number;
  height: number;
};

export default function ChartCard({ title, type, width, height }: Props) {
  const chartConfig = {
    backgroundGradientFrom: "#ffffff",
    backgroundGradientTo: "#ffffff",
    color: (opacity = 1) => `rgba(37, 99, 235, ${opacity})`,
    labelColor: (opacity = 1) => `rgba(15, 23, 42, ${opacity})`,
    decimalPlaces: 0
  };

  const lineData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
    datasets: [{ data: [30, 45, 28, 80, 99, 43] }]
  };
  const barData = {
    labels: ["SEO", "Ads", "Email", "Social", "Ref"],
    datasets: [{ data: [50, 40, 60, 35, 25] }]
  };
  const pieData = [
    { name: "A", population: 40, color: "#3b82f6", legendFontColor: "#0f172a", legendFontSize: 12 },
    { name: "B", population: 30, color: "#10b981", legendFontColor: "#0f172a", legendFontSize: 12 },
    { name: "C", population: 30, color: "#94a3b8", legendFontColor: "#0f172a", legendFontSize: 12 }
  ];
  const stackedBarData = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri"],
    legend: ["iOS", "Android"],
    data: [
      [60, 40],
      [50, 50],
      [40, 60],
      [55, 45],
      [70, 30]
    ],
    barColors: ["#3b82f6", "#10b981"]
  };
  const progressData = {
    labels: ["Signups", "Trials", "Paid"],
    data: [0.8, 0.6, 0.35]
  };

  const Body = () => {
    switch (type) {
      case "line":
        return <LineChart data={lineData} width={width} height={height} chartConfig={chartConfig} bezier />;
      case "bar":
        return <BarChart data={barData} width={width} height={height} chartConfig={chartConfig} />;
      case "pie":
        return <PieChart data={pieData} width={width} height={height} chartConfig={chartConfig} accessor={"population"} backgroundColor={"transparent"} paddingLeft={"16"} />;
      case "stackedBar":
        return <StackedBarChart data={stackedBarData} width={width} height={height} chartConfig={chartConfig} />;
      case "progress":
        return <ProgressChart data={progressData} width={width} height={height} chartConfig={chartConfig} />;
    }
  };

  return (
    <View className="bg-white rounded-3xl p-4 shadow-card">
      <Text className="text-lg font-semibold mb-2">{title}</Text>
      <Body />
    </View>
  );
}
