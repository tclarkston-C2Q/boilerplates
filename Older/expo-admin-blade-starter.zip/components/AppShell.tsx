import React from "react";
import { View } from "react-native";
import { AvatarMenu } from "./AvatarMenu";
import Sidebar from "./Sidebar";

export const AppShell = ({ children }: { children: React.ReactNode }) => {
  return (
    <View className="flex-1 flex-row bg-slate-50">
      <Sidebar />
      <View className="flex-1">
        <View className="h-16 px-4 flex-row items-center justify-between bg-white border-b border-slate-100">
          <View className="flex-row items-center gap-2">
            <View className="w-2 h-2 rounded-full bg-accent-500" />
            <View className="w-2 h-2 rounded-full bg-brand-500" />
          </View>
          <AvatarMenu />
        </View>
        <View className="flex-1">{children}</View>
      </View>
    </View>
  );
};
export default AppShell;
