import React from "react";
import { useLocalSearchParams } from "expo-router";
import { ScrollView } from "react-native";
import UserForm from "../../components/UserForm";
import { Text } from "@gluestack-ui/themed";

export default function EditUser() {
  const { id } = useLocalSearchParams<{id: string}>();
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Text className="text-2xl font-bold mb-4">Edit User #{id}</Text>
      <UserForm mode="edit" />
    </ScrollView>
  );
}
