import React from "react";
import { Slot } from "expo-router";
import BladeNav from "../../components/BladeNav";

export default function UsersLayout() {
  const items = [
    { label: "Users", href: "/(users)", icon: "Users" },
    { label: "Create", href: "/(users)/create", icon: "UserPlus" },
    { label: "Roles", href: "/(users)/roles", icon: "Shield" },
  ];
  return <BladeNav title="User Admin" items={items}><Slot /></BladeNav>;
}
