import React from "react";
import { ScrollView } from "react-native";
import UserForm from "../../components/UserForm";
import { Text } from "@gluestack-ui/themed";

export default function CreateUser() {
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Text className="text-2xl font-bold mb-4">Create User</Text>
      <UserForm />
    </ScrollView>
  );
}
