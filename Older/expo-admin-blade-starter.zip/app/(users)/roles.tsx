import React from "react";
import { ScrollView } from "react-native";
import { Text, Box, VStack, HStack } from "@gluestack-ui/themed";

export default function Roles() {
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Text className="text-2xl font-bold mb-4">Roles</Text>
      <Box className="bg-white rounded-3xl p-4 shadow-card">
        <VStack className="gap-2">
          <HStack className="justify-between"><Text className="font-semibold">Owner</Text><Text>All permissions</Text></HStack>
          <HStack className="justify-between"><Text className="font-semibold">Admin</Text><Text>Manage users & settings</Text></HStack>
          <HStack className="justify-between"><Text className="font-semibold">Member</Text><Text>Basic usage</Text></HStack>
        </VStack>
      </Box>
    </ScrollView>
  );
}
