import React from "react";
import { ScrollView } from "react-native";
import { Text, Box, HStack, VStack, Button, ButtonText } from "@gluestack-ui/themed";
import { Link } from "expo-router";

const USERS = [
  { id: "1", name: "Ava Daniels", email: "ava@example.com", role: "Owner", status: "Active" },
  { id: "2", name: "Ben Lee", email: "ben@example.com", role: "Admin", status: "Active" },
  { id: "3", name: "Carmen Wu", email: "carmen@example.com", role: "Member", status: "Suspended" }
];

export default function UsersList() {
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <HStack className="justify-between items-center mb-4">
        <Text className="text-2xl font-bold">Users</Text>
        <Link href="/(users)/create" asChild>
          <Button className="bg-accent-600 rounded-2xl px-4 py-3">
            <ButtonText>Create User</ButtonText>
          </Button>
        </Link>
      </HStack>

      <Box className="bg-white rounded-3xl shadow-card">
        <VStack className="divide-y divide-slate-100">
          {USERS.map(u => (
            <Link key={u.id} href={`/(users)/${u.id}`} asChild>
              <HStack className="px-4 py-4 items-center justify-between">
                <VStack>
                  <Text className="font-semibold text-slate-900">{u.name}</Text>
                  <Text className="text-slate-500">{u.email}</Text>
                </VStack>
                <HStack className="gap-2">
                  <Box className="px-3 py-1 rounded-full bg-brand-100">
                    <Text className="text-brand-700 text-xs">{u.role}</Text>
                  </Box>
                  <Box className={`px-3 py-1 rounded-full ${u.status === "Active" ? "bg-accent-100" : "bg-slate-200"}`}>
                    <Text className={`text-xs ${u.status === "Active" ? "text-accent-700" : "text-slate-600"}`}>{u.status}</Text>
                  </Box>
                </HStack>
              </HStack>
            </Link>
          ))}
        </VStack>
      </Box>
    </ScrollView>
  );
}
