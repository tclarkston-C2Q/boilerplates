import React from "react";
import "../global.css";
import { Slot } from "expo-router";
import { GluestackUIProvider } from "@gluestack-ui/themed";
import { config } from "../gluestack-ui.config";
import { SafeAreaView } from "react-native-safe-area-context";
import { AppShell } from "../components/AppShell";

export default function RootLayout() {
  return (
    <GluestackUIProvider config={config}>
      <SafeAreaView style={{ flex: 1 }}>
        <AppShell>
          <Slot />
        </AppShell>
      </SafeAreaView>
    </GluestackUIProvider>
  );
}
