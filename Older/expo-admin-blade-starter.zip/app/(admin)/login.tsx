import React from "react";
import { ScrollView } from "react-native";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, Text, Input, InputField, Button, ButtonText, VStack, HStack, LinkText } from "@gluestack-ui/themed";
import { Link, router } from "expo-router";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

export default function Login() {
  const { control, handleSubmit } = useForm({ resolver: zodResolver(schema) });
  const onSubmit = () => router.replace("/(dashboard)");
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Box className="bg-white rounded-3xl p-6 shadow-card">
        <VStack className="gap-4">
          <Text className="text-2xl font-bold">Welcome back</Text>
          <Controller control={control} name="email" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Email" value={value} onChangeText={onChange} keyboardType="email-address" /></Input>
          )} />
          <Controller control={control} name="password" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Password" value={value} onChangeText={onChange} secureTextEntry /></Input>
          )} />
          <Button className="bg-brand-600 rounded-2xl" onPress={handleSubmit(onSubmit)}><ButtonText>Sign in</ButtonText></Button>
          <HStack className="justify-between">
            <Link href="/(admin)/reset-password" asChild><LinkText>Forgot password?</LinkText></Link>
            <Link href="/(users)/create" asChild><LinkText>Create user</LinkText></Link>
          </HStack>
        </VStack>
      </Box>
    </ScrollView>
  );
}
