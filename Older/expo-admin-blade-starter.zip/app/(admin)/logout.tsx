import React, { useEffect } from "react";
import { View } from "react-native";
import { Text } from "@gluestack-ui/themed";
import { router } from "expo-router";

export default function Logout() {
  useEffect(() => {
    const t = setTimeout(() => router.replace("/(admin)/login"), 600);
    return () => clearTimeout(t);
  }, []);
  return (
    <View className="flex-1 items-center justify-center">
      <Text>Signing out…</Text>
    </View>
  );
}
