import React from "react";
import { ScrollView } from "react-native";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, Text, VStack, Input, InputField, Button, ButtonText } from "@gluestack-ui/themed";

const schema = z.object({
  currentPassword: z.string().min(6),
  newPassword: z.string().min(6),
  confirmPassword: z.string().min(6)
}).refine((d) => d.newPassword === d.confirmPassword, { message: "Passwords must match", path: ["confirmPassword"] });

export default function ChangePassword() {
  const { control, handleSubmit } = useForm({ resolver: zodResolver(schema) });
  const onSubmit = () => alert("Password changed (demo).");
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Box className="bg-white rounded-3xl p-6 shadow-card">
        <VStack className="gap-4">
          <Text className="text-2xl font-bold">Change Password</Text>
          <Controller control={control} name="currentPassword" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Current password" value={value} onChangeText={onChange} secureTextEntry /></Input>
          )} />
          <Controller control={control} name="newPassword" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="New password" value={value} onChangeText={onChange} secureTextEntry /></Input>
          )} />
          <Controller control={control} name="confirmPassword" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Confirm new password" value={value} onChangeText={onChange} secureTextEntry /></Input>
          )} />
          <Button className="bg-accent-600 rounded-2xl" onPress={handleSubmit(onSubmit)}><ButtonText>Update Password</ButtonText></Button>
        </VStack>
      </Box>
    </ScrollView>
  );
}
