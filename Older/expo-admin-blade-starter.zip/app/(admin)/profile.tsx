import React from "react";
import { ScrollView, Image } from "react-native";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, Text, VStack, Input, InputField, HStack, Button, ButtonText } from "@gluestack-ui/themed";

const schema = z.object({
  name: z.string().min(2),
  title: z.string().optional(),
  email: z.string().email()
});

export default function Profile() {
  const { control, handleSubmit } = useForm({ resolver: zodResolver(schema) });
  const onSubmit = () => alert("Profile saved (demo).");
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Box className="bg-white rounded-3xl p-6 shadow-card">
        <VStack className="gap-4">
          <HStack className="items-center gap-4">
            <Image source={{ uri: "https://i.pravatar.cc/120" }} style={{ width: 60, height: 60, borderRadius: 999 }} />
            <VStack><Text className="font-semibold">Your avatar</Text><Text className="text-slate-500">Tap to change (not wired)</Text></VStack>
          </HStack>
          <Controller control={control} name="name" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Full name" value={value} onChangeText={onChange} /></Input>
          )} />
          <Controller control={control} name="title" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Job title" value={value as any} onChangeText={onChange} /></Input>
          )} />
          <Controller control={control} name="email" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Email" value={value} onChangeText={onChange} keyboardType="email-address" /></Input>
          )} />
          <Button className="bg-brand-600 rounded-2xl" onPress={handleSubmit(onSubmit)}><ButtonText>Save</ButtonText></Button>
        </VStack>
      </Box>
    </ScrollView>
  );
}
