import React from "react";
import { Slot } from "expo-router";
import BladeNav from "../../components/BladeNav";

export default function AdminLayout() {
  const items = [
    { label: "Login", href: "/(admin)/login", icon: "LogIn" },
    { label: "Reset Password", href: "/(admin)/reset-password", icon: "KeySquare" },
    { label: "Change Password", href: "/(admin)/change-password", icon: "Lock" },
    { label: "Profile", href: "/(admin)/profile", icon: "User" },
    { label: "Logout", href: "/(admin)/logout", icon: "LogOut" }
  ];
  return <BladeNav title="Admin" items={items}><Slot /></BladeNav>;
}
