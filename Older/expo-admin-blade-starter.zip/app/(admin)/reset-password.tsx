import React from "react";
import { ScrollView } from "react-native";
import { useForm, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Box, Text, Input, InputField, Button, ButtonText, VStack } from "@gluestack-ui/themed";

const schema = z.object({ email: z.string().email() });

export default function ResetPassword() {
  const { control, handleSubmit } = useForm({ resolver: zodResolver(schema) });
  const onSubmit = () => alert("If this were connected, we'd send a reset link.");
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Box className="bg-white rounded-3xl p-6 shadow-card">
        <VStack className="gap-4">
          <Text className="text-2xl font-bold">Reset password</Text>
          <Controller control={control} name="email" render={({ field: { onChange, value } }) => (
            <Input className="rounded-2xl"><InputField placeholder="Email" value={value} onChangeText={onChange} keyboardType="email-address" /></Input>
          )} />
          <Button className="bg-accent-600 rounded-2xl" onPress={handleSubmit(onSubmit)}><ButtonText>Send reset link</ButtonText></Button>
        </VStack>
      </Box>
    </ScrollView>
  );
}
