import React from "react";
import { ScrollView } from "react-native";
import { Text, HStack, Box } from "@gluestack-ui/themed";

export default function Themes() {
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Text className="text-2xl font-bold mb-4">Themes</Text>
      <HStack className="gap-4">
        <Box className="flex-1 h-24 bg-brand-500 rounded-3xl shadow-card" />
        <Box className="flex-1 h-24 bg-accent-500 rounded-3xl shadow-card" />
      </HStack>
    </ScrollView>
  );
}
