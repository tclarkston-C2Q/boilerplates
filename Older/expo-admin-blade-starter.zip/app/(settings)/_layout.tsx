import React from "react";
import { Slot } from "expo-router";
import BladeNav from "../../components/BladeNav";

export default function SettingsLayout() {
  const items = [
    { label: "General", href: "/(settings)", icon: "Settings" },
    { label: "Themes", href: "/(settings)/themes", icon: "Palette" },
  ];
  return <BladeNav title="Settings" items={items}><Slot /></BladeNav>;
}
