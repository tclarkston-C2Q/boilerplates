import React from "react";
import { ScrollView } from "react-native";
import { Text, Box, Switch, SwitchThumb, HStack } from "@gluestack-ui/themed";

export default function GeneralSettings() {
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Text className="text-2xl font-bold mb-4">General</Text>
      <Box className="bg-white rounded-3xl p-4 shadow-card">
        <HStack className="items-center justify-between">
          <Text>Enable advanced analytics</Text>
          <Switch className="bg-brand-600 rounded-full" value={true}><SwitchThumb /></Switch>
        </HStack>
      </Box>
    </ScrollView>
  );
}
