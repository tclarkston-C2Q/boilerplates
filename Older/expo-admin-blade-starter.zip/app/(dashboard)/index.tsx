import React from "react";
import { ScrollView, Dimensions } from "react-native";
import { Text, Box, HStack, VStack } from "@gluestack-ui/themed";
import ChartCard from "../../components/ChartCard";

export default function DashboardHome() {
  const width = Dimensions.get("window").width - 48;
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Text className="text-2xl font-bold mb-4 text-slate-900">Executive Overview</Text>
      <HStack className="gap-4 mb-4">
        <Box className="flex-1 bg-white rounded-3xl shadow-card p-4">
          <Text className="text-slate-500">Revenue</Text>
          <Text className="text-3xl font-extrabold text-brand-600">$145,230</Text>
        </Box>
        <Box className="flex-1 bg-white rounded-3xl shadow-card p-4">
          <Text className="text-slate-500">Active Users</Text>
          <Text className="text-3xl font-extrabold text-accent-600">12,483</Text>
        </Box>
      </HStack>

      <VStack className="gap-4">
        <ChartCard title="Monthly Revenue" type="line" width={width} height={220} />
        <ChartCard title="New Users by Channel" type="bar" width={width} height={220} />
        <ChartCard title="Product Mix" type="pie" width={width} height={220} />
      </VStack>
    </ScrollView>
  );
}
