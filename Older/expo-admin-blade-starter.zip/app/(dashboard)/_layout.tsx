import React from "react";
import { Slot } from "expo-router";
import BladeNav from "../../components/BladeNav";

export default function DashboardLayout() {
  const items = [
    { label: "Overview", href: "/(dashboard)", icon: "LayoutDashboard" },
    { label: "Reports", href: "/(dashboard)/reports", icon: "BarChart3" },
    { label: "KPIs", href: "/(dashboard)/kpis", icon: "Activity" },
  ];
  return <BladeNav title="Dashboard" items={items}><Slot /></BladeNav>;
}
