import React from "react";
import { ScrollView, Dimensions } from "react-native";
import ChartCard from "../../components/ChartCard";
import { Text } from "@gluestack-ui/themed";

export default function KPIs() {
  const width = Dimensions.get("window").width - 48;
  return (
    <ScrollView className="flex-1 p-4 bg-slate-50">
      <Text className="text-2xl font-bold mb-4">KPIs</Text>
      <ChartCard title="Conversion Funnel" type="progress" width={width} height={200} />
    </ScrollView>
  );
}
