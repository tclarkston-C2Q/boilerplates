/** @type {import('tailwindcss').Config} */
const { tokens } = require('./theme/tokens.cjs')
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './components/**/*.{js,jsx,ts,tsx}', './ui/**/*.{js,jsx,ts,tsx}'],
  presets: [require('nativewind/preset')],
  darkMode: 'class',
  theme: {
    extend: {
      colors: { primary: tokens.colors.primary, surface: tokens.colors.surface, neutral: tokens.colors.neutral },
      borderRadius: tokens.radii,
      spacing: tokens.space,
      fontFamily: { sans: ['Inter'] },
    },
  },
}
