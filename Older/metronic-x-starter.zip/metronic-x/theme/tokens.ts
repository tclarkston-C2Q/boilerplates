export const tokens = {
  colors: {
    primary: { 50:'#eef2ff',100:'#e0e7ff',200:'#c7d2fe',300:'#a5b4fc',400:'#818cf8',500:'#6366f1',600:'#4f46e5',700:'#4338ca',800:'#3730a3',900:'#312e81' },
    neutral: { 50:'#f8fafc',100:'#f1f5f9',200:'#e2e8f0',600:'#475569',700:'#334155',800:'#1f2937',900:'#0f172a' },
    surface: { 0:'#0b0b0c', 50:'#0f1115',100:'#111318',900:'#ffffff' },
    success: { 500:'#16a34a' }, warning: { 500:'#f59e0b' }, danger: { 500:'#ef4444' }
  },
  radii: { sm:6, md:10, lg:16, xl:24 },
  space: { xs:4, sm:8, md:12, lg:16, xl:24 },
  font: { sans: 'Inter' }
} as const
