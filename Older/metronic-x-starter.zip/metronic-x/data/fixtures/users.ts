export type User = { id: string; name: string; email: string; role: 'admin'|'manager'|'viewer'; active: boolean; createdAt: string }
export const users: User[] = [
  { id:'u_01', name:'Ava Lopez', email:'ava@example.com', role:'admin', active:true, createdAt:'2025-06-01' },
  { id:'u_02', name:'Ben Park', email:'ben@example.com', role:'manager', active:false, createdAt:'2025-06-03' },
]
