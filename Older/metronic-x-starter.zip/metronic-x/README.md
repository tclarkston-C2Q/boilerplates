# Metronic-X (Expo + RNW + NativeWind + GlueStack + RN Chart Kit)

Client-only admin shell template. This starter mirrors common Metronic IA patterns without reusing Metronic assets.

## Quickstart

```bash
# 1) Install deps
npm i -g expo-cli # if needed
npm install

# 2) Add required libs via Expo (ensures compatible versions)
npx expo install expo-router react-native-safe-area-context react-native-screens expo-linking expo-constants expo-status-bar
npx expo install react-native-web react-dom
npx expo install @expo-google-fonts/inter expo-font
npm i nativewind tailwindcss prettier-plugin-tailwindcss
npx expo install react-native-reanimated react-native-safe-area-context
npm i react-native-chart-kit
npx expo install react-native-svg
npm i i18next react-i18next
npx expo install expo-localization

# 3) (Optional) GlueStack UI init
# npx gluestack-ui init

# 4) Run
npm run web    # or npm run ios / android
```

> Note: This starter is **client-only** (no backend). Data lives in fixtures under `data/`.

## Structure
- `app/` routes via Expo Router
- `components/` shared shell & widgets
- `providers/` theming, RBAC, i18n
- `ui/` thin component wrappers (swap for GlueStack primitives later)
- `theme/` tokens (TS + CJS for Tailwind)
