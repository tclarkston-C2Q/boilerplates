import { View, Text, Pressable } from 'react-native'
import { Link, usePathname } from 'expo-router'
import * as React from 'react'

const NavItem = ({ href, label }: { href: string; label: string }) => {
  const active = usePathname() === href
  return (
    <Link href={href} asChild>
      <Pressable className={`px-3 py-2 rounded-lg ${active ? 'bg-primary-100' : 'hover:bg-neutral-100'}`}>
        <Text className={`text-sm ${active ? 'text-primary-700 font-semibold' : 'text-neutral-700'}`}>{label}</Text>
      </Pressable>
    </Link>
  )
}
export function Sidebar() {
  return (
    <View className="w-64 gap-1 p-3 hidden md:flex" accessibilityRole="navigation">
      <NavItem href="/(dashboard)" label="Dashboard" />
      <NavItem href="/(users)" label="Users" />
      <NavItem href="/(roles)" label="Roles" />
      <NavItem href="/(settings)" label="Settings" />
    </View>
  )
}
