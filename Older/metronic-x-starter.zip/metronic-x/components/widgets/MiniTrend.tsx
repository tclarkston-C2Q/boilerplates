import { LineChart } from 'react-native-chart-kit'
import { Dimensions, View, Text } from 'react-native'
import * as React from 'react'

const width = Math.min(640, Dimensions.get('window').width - 32)
export function MiniTrend() {
  const data = { labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], datasets: [{ data: [12,19,9,17,23,18,27] }] }
  return (
    <View className="p-4 rounded-2xl bg-white dark:bg-surface-50">
      <Text className="text-base font-semibold mb-2">Weekly Signups</Text>
      <LineChart data={data} width={width} height={180} withInnerLines chartConfig={{ backgroundGradientFromOpacity:0, backgroundGradientToOpacity:0, color:(o=1)=>`rgba(79,70,229,${o})`, labelColor:()=> '#64748b' }} bezier style={{ borderRadius: 16 }} />
    </View>
  )
}
