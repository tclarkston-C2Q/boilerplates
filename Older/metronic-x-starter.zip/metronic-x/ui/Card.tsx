import * as React from 'react'
import { View, ViewProps } from 'react-native'

export function Card({ className='', ...rest }: ViewProps & { className?: string }) {
  return <View className={`bg-white dark:bg-surface-50 rounded-2xl border border-neutral-200 ${className}`} {...rest} />
}
