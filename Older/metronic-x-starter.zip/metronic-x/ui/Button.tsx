import * as React from 'react'
import { Pressable, Text, PressableProps } from 'react-native'

type Props = PressableProps & { variant?: 'solid'|'outline'|'ghost' }
export function Button({ variant='solid', children, className='', ...rest }: React.PropsWithChildren<Props>) {
  const base = 'px-3 py-2 rounded-lg'
  const styles = variant === 'outline'
    ? 'border border-primary-600 text-primary-700'
    : variant === 'ghost'
    ? 'text-primary-700'
    : 'bg-primary-600'
  const textClass = variant === 'solid' ? 'text-white' : 'text-primary-700'
  return (
    <Pressable accessibilityRole="button" className={`${base} ${styles} ${className}`} {...rest}>
      <Text className={`text-sm ${textClass}`}>{children}</Text>
    </Pressable>
  )
}
