import { View, Text } from 'react-native'
import { Stack } from 'expo-router'
import { Sidebar } from '../components/shell/Sidebar'
import { RootProvider } from '../providers/RootProvider'
import { useFonts, Inter_400Regular, Inter_600SemiBold } from '@expo-google-fonts/inter'
import * as React from 'react'

export default function RootLayout() {
  const [loaded] = useFonts({ Inter_400Regular, Inter_600SemiBold })
  if (!loaded) return <View style={{ flex:1, alignItems:'center', justifyContent:'center' }}><Text>Loading…</Text></View>
  return (
    <RootProvider>
      <View className="flex-1 md:flex-row">
        <Sidebar />
        <View className="flex-1">
          <Stack screenOptions={{ headerShown: false }} />
        </View>
      </View>
    </RootProvider>
  )
}
