import * as React from 'react'
import { View, Text, TextInput, Pressable, FlatList } from 'react-native'
import { users as seed, User } from '../../data/fixtures/users'

export default function UsersIndex() {
  const [q, setQ] = React.useState('')
  const [sort, setSort] = React.useState<{ key: keyof User; dir:'asc'|'desc' } | null>({ key: 'name', dir: 'asc' })
  const rows = React.useMemo(() => {
    const f = q ? seed.filter(u => u.name.toLowerCase().includes(q.toLowerCase()) || u.email.toLowerCase().includes(q.toLowerCase())) : seed
    if (!sort) return f
    const { key, dir } = sort
    return [...f].sort((a,b)=> (a[key] > b[key] ? 1 : -1) * (dir==='asc'?1:-1))
  }, [q, sort])

  return (
    <View className="flex-1 p-4 gap-3">
      <View className="flex-row gap-2 items-center">
        <TextInput placeholder="Search users" className="flex-1 px-3 py-2 rounded-lg bg-neutral-100" value={q} onChangeText={setQ} />
        <Pressable className="px-3 py-2 rounded-lg bg-primary-600"><Text className="text-white">New User</Text></Pressable>
      </View>
      <View className="rounded-2xl overflow-hidden border border-neutral-200">
        <View className="flex-row bg-neutral-50">
          {['name','email','role','active'].map((k)=> (
            <Pressable key={k} className="p-3" onPress={()=> setSort(s=> ({ key: k as keyof User, dir: s?.dir==='asc'?'desc':'asc' }))}>
              <Text className="text-xs font-semibold text-neutral-700">{k.toUpperCase()}</Text>
            </Pressable>
          ))}
        </View>
        <FlatList data={rows} keyExtractor={r=>r.id} renderItem={({ item }) => (
          <View className="flex-row border-t border-neutral-100">
            <Text className="p-3 w-48">{item.name}</Text>
            <Text className="p-3 flex-1">{item.email}</Text>
            <Text className="p-3 w-32">{item.role}</Text>
            <Text className="p-3 w-24">{item.active ? 'Yes' : 'No'}</Text>
          </View>
        )} />
      </View>
    </View>
  )
}
