import * as React from 'react'
import { View, Text } from 'react-native'

export default function UserDetail() {
  return (
    <View className="flex-1 p-4">
      <Text className="text-xl font-semibold">User Detail</Text>
      <Text className="text-neutral-600">Placeholder for user details/edit form.</Text>
    </View>
  )
}
