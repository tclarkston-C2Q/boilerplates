import * as React from 'react'
import { ScrollView, View, Text } from 'react-native'
import { Button } from '../../ui/Button'
import { Card } from '../../ui/Card'
import { MiniTrend } from '../../components/widgets/MiniTrend'

export default function ComponentsCatalog() {
  return (
    <ScrollView className="flex-1 p-4 gap-4">
      <Text className="text-xl font-semibold">Components Catalog</Text>

      <Card className="p-4 gap-3">
        <Text className="text-base font-semibold">Buttons</Text>
        <View className="flex-row gap-2">
          <Button>Primary</Button>
          <Button variant="outline">Outline</Button>
          <Button variant="ghost">Ghost</Button>
        </View>
      </Card>

      <Card className="p-4 gap-3">
        <Text className="text-base font-semibold">Chart</Text>
        <MiniTrend />
      </Card>

      <Card className="p-4 gap-3">
        <Text className="text-base font-semibold">Tokens</Text>
        <View className="flex-row gap-2">
          <View className="w-8 h-8 rounded-md bg-primary-600" />
          <View className="w-8 h-8 rounded-md bg-neutral-100" />
          <View className="w-8 h-8 rounded-md bg-neutral-900" />
        </View>
      </Card>
    </ScrollView>
  )
}
