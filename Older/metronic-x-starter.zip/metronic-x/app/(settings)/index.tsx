import * as React from 'react'
import { View, Text } from 'react-native'
import { Link } from 'expo-router'

export default function SettingsIndex() {
  return (
    <View className="flex-1 p-4 gap-3">
      <Text className="text-xl font-semibold">Settings</Text>
      <Link href="/(settings)/components"><Text className="text-primary-700">Open Component Catalog →</Text></Link>
    </View>
  )
}
