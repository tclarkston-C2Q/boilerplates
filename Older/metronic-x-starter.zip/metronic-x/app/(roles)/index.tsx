import * as React from 'react'
import { View, Text } from 'react-native'

export default function RolesIndex() {
  return (
    <View className="flex-1 p-4">
      <Text className="text-xl font-semibold">Roles & Permissions</Text>
      <Text className="text-neutral-600">Client-only RBAC demo coming soon.</Text>
    </View>
  )
}
