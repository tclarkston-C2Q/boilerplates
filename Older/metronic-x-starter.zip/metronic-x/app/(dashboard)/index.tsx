import * as React from 'react'
import { View, Text } from 'react-native'
import { Card } from '../../ui/Card'
import { MiniTrend } from '../../components/widgets/MiniTrend'

export default function Dashboard() {
  return (
    <View className="flex-1 p-4 gap-4">
      <Text className="text-xl font-semibold">Dashboard</Text>
      <View className="flex-row gap-4 flex-wrap">
        <Card className="p-4 w-64"><Text className="text-sm text-neutral-600">Active Users</Text><Text className="text-2xl font-semibold">1,284</Text></Card>
        <Card className="p-4 w-64"><Text className="text-sm text-neutral-600">MRR</Text><Text className="text-2xl font-semibold">$24,890</Text></Card>
        <Card className="p-4 w-64"><Text className="text-sm text-neutral-600">NPS</Text><Text className="text-2xl font-semibold">42</Text></Card>
      </View>
      <MiniTrend />
    </View>
  )
}
