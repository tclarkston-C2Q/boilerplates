import React, { createContext, PropsWithChildren, useContext, useMemo } from 'react'

type Role = 'admin'|'manager'|'viewer'
const capabilities: Record<Role, string[]> = {
  admin: ['user:create','user:edit','user:delete','settings:edit'],
  manager: ['user:edit'],
  viewer: []
}
const Rbac = createContext<{ role: Role; can: (cap: string) => boolean }>({ role:'viewer', can: ()=>false })
export const useRbac = () => useContext(Rbac)
export function RbacProvider({ role='viewer', children }: PropsWithChildren<{ role?: Role }>) {
  const value = useMemo(()=> ({ role, can: (cap: string)=> capabilities[role].includes(cap) }), [role])
  return <Rbac.Provider value={value}>{children}</Rbac.Provider>
}
