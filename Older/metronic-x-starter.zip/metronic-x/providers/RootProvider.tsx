import { PropsWithChildren } from 'react'
import { GluestackUIProvider } from '@gluestack-ui/themed'
import { tokens } from '../theme/tokens'

export function RootProvider({ children }: PropsWithChildren) {
  return (
    <GluestackUIProvider config={{ tokens }}>
      {children}
    </GluestackUIProvider>
  )
}
