
# Realtime Telemetry Dashboard

- Pause/resume stream
- Select time window (30s/60s/2m)
- Downsampling to cap render cost
- Export CSV
- UX-styled area chart

Run:
```bash
npm i
npm run dev
```
