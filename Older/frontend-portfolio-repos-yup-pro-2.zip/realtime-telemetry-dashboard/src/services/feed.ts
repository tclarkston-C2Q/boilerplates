
export type Point = { t: number; v: number }

export function startFeed(cb: (p: Point) => void){
  let t = Date.now()
  const id = setInterval(()=>{
    t += 500
    const noise = (Math.random()-0.5)*8
    const v = 50 + 8*Math.sin(t/3500) + noise
    cb({ t, v: Math.round(v*100)/100 })
  }, 500)
  return () => clearInterval(id)
}
