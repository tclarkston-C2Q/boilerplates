
import { useEffect, useMemo, useRef, useState } from 'react'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { togglePaused, setWindow } from '../state/controlsSlice'
import { startFeed, Point } from '../services/feed'
import { CSVLink } from './CSVLink'
import { AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from 'recharts'

function downsample(data: Point[], maxPoints=200){
  if(data.length <= maxPoints) return data
  const stride = Math.ceil(data.length / maxPoints)
  const res: Point[] = []
  for(let i=0;i<data.length;i+=stride) res.push(data[i])
  return res
}

export function Dashboard(){
  const dispatch = useAppDispatch()
  const { paused, windowSec } = useAppSelector(s=>s.controls)
  const [raw, setRaw] = useState<Point[]>([])
  const stopRef = useRef<() => void>()

  useEffect(()=>{
    if(!paused){
      stopRef.current = startFeed(p => {
        setRaw(prev => {
          const cutoff = Date.now() - windowSec*1000
          const next = [...prev, p].filter(pt => pt.t >= cutoff)
          return next
        })
      })
    }
    return () => { stopRef.current && stopRef.current() }
  }, [paused, windowSec])

  const sampled = useMemo(()=>downsample(raw, 240), [raw])

  return (
    <div className="card">
      <div className="toolbar">
        <button className="btn" onClick={()=>dispatch(togglePaused())}>{paused ? 'Resume' : 'Pause'}</button>
        <select onChange={(e)=>dispatch(setWindow(Number(e.target.value)))} value={windowSec}>
          <option value={30}>Last 30s</option>
          <option value={60}>Last 60s</option>
          <option value={120}>Last 2m</option>
        </select>
        <CSVLink data={sampled} filename="telemetry.csv" />
        <span className="muted">Points: {sampled.length}</span>
      </div>
      <div className="spacer"/>
      <ResponsiveContainer width="100%" height={320}>
        <AreaChart data={sampled}>
          <defs>
            <linearGradient id="g" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#6ca2ff" stopOpacity={0.8}/>
              <stop offset="95%" stopColor="#6ca2ff" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="t" tickFormatter={(v)=>new Date(v).toLocaleTimeString()} />
          <YAxis />
          <Tooltip />
          <Area type="monotone" dataKey="v" stroke="#6ca2ff" fillOpacity={1} fill="url(#g)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
