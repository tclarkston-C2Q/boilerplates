
import { Point } from '../services/feed'

export function CSVLink({ data, filename }: { data: Point[], filename: string }){
  const csv = ['t,v', ...data.map(d=>`${d.t},${d.v}`)].join('\n')
  const blob = new Blob([csv], { type: 'text/csv' })
  const href = URL.createObjectURL(blob)
  return <a className="pill" download={filename} href={href}>Export CSV</a>
}
