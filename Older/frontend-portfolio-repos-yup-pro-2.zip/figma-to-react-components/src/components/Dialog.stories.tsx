
import type { Meta, StoryObj } from '@storybook/react'
import { useState } from 'react'
import { Dialog } from './Dialog'
import { Button } from './Button'

function Demo(){
  const [open, setOpen] = useState(false)
  return (
    <div>
      <Button onClick={()=>setOpen(true)}>Open Dialog</Button>
      <Dialog open={open} onClose={()=>setOpen(false)} title="Dialog Title">
        <p>Dialog content goes here.</p>
      </Dialog>
    </div>
  )
}

const meta: Meta<typeof Demo> = { title: 'Components/Dialog', component: Demo }
export default meta
type Story = StoryObj<typeof Demo>
export const Basic: Story = {}
