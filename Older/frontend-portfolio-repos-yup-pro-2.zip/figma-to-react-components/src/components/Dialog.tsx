
import { useEffect } from 'react'

export function Dialog({ open, onClose, title, children }: { open: boolean, onClose: ()=>void, title: string, children: any }){
  useEffect(()=>{
    const onKey = (e: KeyboardEvent) => { if(e.key === 'Escape') onClose() }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [onClose])
  if(!open) return null
  return (
    <div role="dialog" aria-modal="true" aria-label={title}
      style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.4)', display:'grid', placeItems:'center', padding:20 }}>
      <div className="ws-card" style={{ maxWidth:520, width:'100%' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <h3 style={{ margin:0 }}>{title}</h3>
          <button className="ws-btn" onClick={onClose}>Close</button>
        </div>
        <div style={{ height:12 }} />
        {children}
      </div>
    </div>
  )
}
