
import type { Preview } from '@storybook/react'
import '../src/tokens.css'
const preview: Preview = {}
export default preview
