
# Figma → React Components

- Tokens via CSS variables
- Accessible primitives: Button, Input, Dialog
- Storybook stories included

Run:
```bash
npm i
npm run storybook
```
