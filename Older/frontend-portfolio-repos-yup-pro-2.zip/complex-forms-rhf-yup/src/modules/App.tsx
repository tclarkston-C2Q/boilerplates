
import { Wizard } from './Wizard'
export function App(){ return <div className="container"><Wizard/></div> }
