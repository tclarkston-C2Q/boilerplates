
import { useState } from 'react'
import { useForm } from 'react-hook-form'
import * as yup from 'yup'
import { yupResolver } from '@hookform/resolvers/yup'
import { Field } from './Field'

const schema = yup.object({
  name: yup.string().min(2,'Too short').required('Required'),
  email: yup.string().email('Invalid email').required('Required'),
  plan: yup.mixed<'basic'|'pro'|'enterprise'>().oneOf(['basic','pro','enterprise']).required('Required'),
  agree: yup.boolean().oneOf([true], 'You must accept')
})
type FormData = yup.InferType<typeof schema>

export function Wizard(){
  const [step, setStep] = useState(1)
  const { register, handleSubmit, formState: { errors }, watch } = useForm<FormData>({
    resolver: yupResolver(schema),
    defaultValues: { plan: 'basic', agree: false }
  })

  const onSubmit = (data: FormData) => {
    alert('Submitted: ' + JSON.stringify(data, null, 2))
  }

  return (
    <div className="card">
      <h2>Signup Wizard</h2>
      <p className="muted">Step {step} of 3</p>
      <form onSubmit={handleSubmit(onSubmit)}>
        {step === 1 && (
          <div className="row cols-2">
            <Field label="Name" error={errors.name?.message}><input {...register('name')} /></Field>
            <Field label="Email" error={errors.email?.message}><input {...register('email')} /></Field>
          </div>
        )}
        {step === 2 && (
          <div className="row cols-2">
            <Field label="Plan" error={errors.plan?.message}>
              <select {...register('plan')}>
                <option value="basic">Basic</option>
                <option value="pro">Pro</option>
                <option value="enterprise">Enterprise</option>
              </select>
            </Field>
            <div>
              <label><input type="checkbox" {...register('agree')} /> I agree to terms</label>
              {errors.agree && <div className="muted" role="alert">{errors.agree.message}</div>}
            </div>
          </div>
        )}
        {step === 3 && (
          <div className="card" style={{background:'#0e1726'}}>
            <pre>{JSON.stringify(watch(), null, 2)}</pre>
          </div>
        )}
        <div className="spacer"/>
        <div className="toolbar">
          {step>1 && <button type="button" className="btn ghost" onClick={()=>setStep(step-1)}>Back</button>}
          {step<3 && <button type="button" className="btn" onClick={()=>setStep(step+1)}>Next</button>}
          {step===3 && <button className="btn" type="submit">Submit</button>}
        </div>
      </form>
    </div>
  )
}
