
import { ReactNode } from 'react'
export function Field({ label, error, children }:{ label: string, error?: string, children: ReactNode }){
  return (
    <div>
      <label className="ws-label">{label}</label>
      {children}
      {error && <div className="muted" role="alert">{error}</div>}
    </div>
  )
}
