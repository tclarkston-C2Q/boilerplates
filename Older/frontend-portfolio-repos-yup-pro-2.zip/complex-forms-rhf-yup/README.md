
# Complex Forms (RHF + Yup)

- 3-step wizard (details → plan → review)
- Field wrapper with a11y error reads
- Styled layout with cards, toolbar, buttons

Run:
```bash
npm i
npm run dev
```
