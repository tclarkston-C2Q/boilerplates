
# React + TypeScript Starter (Redux Toolkit + React Query + Yup)

**What you get**
- Router (Home, Settings), Error Boundary, theming via Redux
- Mock API with React Query (staleTime, loading states)
- Runtime validation with **Yup** (no Zod)
- UX-styled layout with cards, pills, and buttons

Run:
```bash
npm i
npm run dev
```
