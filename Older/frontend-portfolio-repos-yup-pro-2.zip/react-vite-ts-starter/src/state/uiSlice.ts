
import { createSlice, PayloadAction } from '@reduxjs/toolkit'
type UiState = { theme: 'light'|'dark' }
const initial: UiState = { theme: 'light' }
const slice = createSlice({
  name: 'ui',
  initialState: initial,
  reducers: { setTheme(s, a: PayloadAction<UiState['theme']>) { s.theme = a.payload } }
})
export const { setTheme } = slice.actions
export default slice.reducer
