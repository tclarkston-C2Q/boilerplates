
import { useState } from 'react'
import * as yup from 'yup'

const schema = yup.object({
  endpoint: yup.string().url('Must be a valid URL').required('Required'),
  interval: yup.number().min(1,'Min 1s').max(60,'Max 60s').required('Required')
})

export function Settings(){
  const [endpoint, setEndpoint] = useState('https://api.example.com')
  const [interval, setInterval] = useState(10)
  const [msg, setMsg] = useState<string>('')

  const onSave = async () => {
    try{
      await schema.validate({ endpoint, interval }, { abortEarly: false })
      setMsg('Saved ✔')
    } catch (e: any){
      const lines = e.inner?.map((er: any)=>`${er.path}: ${er.message}`) ?? [e.message]
      setMsg(lines.join('\n'))
    }
  }

  return (
    <div className="card">
      <h2>Settings</h2>
      <div className="row cols-2">
        <div>
          <label>API Endpoint</label>
          <input value={endpoint} onChange={e=>setEndpoint(e.target.value)} />
        </div>
        <div>
          <label>Refresh Interval (s)</label>
          <input type="number" value={interval} onChange={e=>setInterval(Number(e.target.value))} />
        </div>
      </div>
      <div className="spacer"/>
      <button className="btn" onClick={onSave}>Save</button>
      {msg && <pre className="muted">{msg}</pre>}
    </div>
  )
}
