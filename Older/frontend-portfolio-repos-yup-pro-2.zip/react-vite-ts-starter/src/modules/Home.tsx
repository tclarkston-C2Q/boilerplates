
import { useQuery } from '@tanstack/react-query'
import { useAppDispatch, useAppSelector } from '../state/hooks'
import { setTheme } from '../state/uiSlice'

async function fetchStatus(){
  await new Promise(r=>setTimeout(r, 300))
  return { api: 'ok', time: new Date().toISOString() }
}

export function Home(){
  const theme = useAppSelector(s => s.ui.theme)
  const dispatch = useAppDispatch()
  const { data, isLoading } = useQuery({ queryKey: ['status'], queryFn: fetchStatus, staleTime: 5_000 })

  return (
    <div className="card">
      <h2>Welcome</h2>
      <p className="muted">Environment: <span className="pill">local</span></p>
      {isLoading ? <p>Loading…</p> : <p>Status: <strong>{data?.api}</strong> at {data?.time}</p>}
      <div className="spacer"/>
      <div className="toolbar">
        <button className="btn" onClick={() => dispatch(setTheme(theme==='light'?'dark':'light'))}>
          Toggle Theme (current: {theme})
        </button>
        <button className="btn ghost" onClick={() => { throw new Error('Demo error') }}>Trigger Error</button>
      </div>
    </div>
  )
}
