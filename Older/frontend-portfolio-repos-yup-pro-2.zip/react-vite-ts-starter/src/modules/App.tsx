
import { Provider } from 'react-redux'
import { store } from '../state/store'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom'
import { Home } from './Home'
import { Settings } from './Settings'
import { ErrorBoundary } from './ErrorBoundary'

const qc = new QueryClient()

export function App(){
  return (
    <Provider store={store}>
      <QueryClientProvider client={qc}>
        <BrowserRouter>
          <div className="container">
            <header className="toolbar">
              <h1 style={{margin:0}}>Starter</h1>
              <Link to="/" className="pill">Home</Link>
              <Link to="/settings" className="pill">Settings</Link>
            </header>
            <div className="spacer" />
            <ErrorBoundary>
              <Routes>
                <Route path="/" element={<Home/>} />
                <Route path="/settings" element={<Settings/>} />
              </Routes>
            </ErrorBoundary>
          </div>
        </BrowserRouter>
      </QueryClientProvider>
    </Provider>
  )
}
