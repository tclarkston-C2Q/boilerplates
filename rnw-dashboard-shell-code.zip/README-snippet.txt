This zip contains only the source code and config files for the React Native Web admin dashboard shell.

Use it inside a fresh Expo app (blank TypeScript template). See the main ChatGPT answer for integration steps.
